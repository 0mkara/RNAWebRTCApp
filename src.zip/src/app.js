// @flow
import React, { Component } from 'react';
import Router from './router';

class RNAWebRTCApp extends Component {
    render() {
        return (
            <Router />
        );
    }
}

export default RNAWebRTCApp;
