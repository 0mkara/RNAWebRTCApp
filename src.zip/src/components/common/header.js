import React from 'react';
import { Text, TouchableOpacity, View } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { scale, verticalScale } from '../scaling';

const styles = {
    headerStyle: {
        height: 40,
        paddingLeft: 0,
        paddingRight: 15,
        borderRadius: 5
    }
};

const Header = () => {
    return (
    <View style={{paddingTop: 25, backgroundColor: 'aliceblue', paddingHorizontal: 10}}>
        <LinearGradient
          colors={['#19e8b3', '#abed57']}
          start={{x: 0.0, y: 0.0}} end={{x: 1.0, y: 0.0}}
          style={styles.headerStyle}>
              <View style={{backgroundColor: 'transparent', flex: 1, flexDirection: 'row', justifyContent: 'center'}}>
                  <View style={{flex: 0.1, justifyContent: 'center'}}>
                      <TouchableOpacity
                      onPress={() => {
                          goBack()
                      }}>
                        <View style={{backgroundColor: 'transparent'}}>
                          <Image
                              style={{height: 40, backgroundColor: 'transparent'}}
                              source={require('../../images/back.png')}
                          />
                        </View>
                      </TouchableOpacity>
                  </View>
                  <View style={{flex: 1, justifyContent: 'center'}}>
                      <Text style={{color: '#fff', fontWeight: '600'}}>UserName</Text>
                      <Text style={{color: '#fff'}}>Ak-_ufNcO5L_v_ZHAAAF</Text>
                  </View>
                  <View style={{flex: 0.2, alignItems: 'flex-end', justifyContent: 'center'}}>
                  <TouchableOpacity
                  onPress={() => {
                      navigation.navigate('DrawerOpen')
                  }}>
                      <Image
                          source={require('../../images/ic_menu.png')}
                      />
                    </TouchableOpacity>
                </View>
            </View>
        </LinearGradient>
    </View>
  );
};
export { Header };