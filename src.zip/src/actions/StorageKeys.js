// @flow
export const MEMBERS_KEY = '@RNAWebRTCApp:room_members';
export const ROOMS_KEY = '@RNAWebRTCApp:rooms';
